import jQuery from 'jquery';
window.$ = jQuery;
window.jQuery = jQuery;

import 'bootstrap/js/dist/tab';
import 'bootstrap/js/dist/modal';